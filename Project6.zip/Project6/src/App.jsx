import { useState } from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
import { UpBar } from './componentes/upBar'
import './App.css'

function App() {
  return (
    <div>
      <UpBar/>
      <section id="welcome-section" className="section welcome">
        <div className="container">
          <h1>I am Lukas</h1>
          <p>Computer Science Student</p>
        </div>
      </section>

      <section id="projects" className="section projects">
        <div className="container">
          <h1>Alguns dos meus projetos</h1>
          <div className="projects">
            <div className="project">
              <img className="project-img" src="/src/imagens/bancoPy.png" alt="" />
              <a className="project-link" href="https://github.com/Lukas-Christopher13/Banco">
                <div className="project-title-button">
                  <p className="project-title">Banco Python</p>
                </div>
              </a>
            </div>

            <div className="project">
              <img className="project-img" src="src/imagens/locadora.png" alt="" />
              <a className="project-link" href="">
                <div className="project-title-button">
                  <p className="project-title">Locadora de Midias</p>
                </div>
              </a>
            </div>

            <div className="project">
              <img className="project-img" src="https://carloshdelreal.com/assets/portfolio/microverse/calculator/home.png" alt="" />
              <a className="project-link" href="">
                <div className="project-title-button">
                  <p className="project-title">Calculadora</p>
                </div>
              </a>
            </div>
          </div>
        </div>
      </section>

      <section id="contact" className="section contact">
        <div className="container">
          <h1>Vamos Trabalhar Juntos!</h1>
          <div className="social-icons">
            <a href="">
              <img src="https://cdn-icons-png.flaticon.com/512/174/174855.png" alt="" />
            </a>
            <a href="https://www.linkedin.com/in/lukas-christopher-de-souza-santana-968997248/">
              <img src="https://cdn-icons-png.flaticon.com/512/3536/3536505.png" alt="" />
            </a>
            <a href="">
              <img src="https://cdn-icons-png.flaticon.com/512/733/733547.png" alt="" />
            </a>
            <a href="https://github.com/Lukas-Christopher13">
              <img src="https://cdn-icons-png.flaticon.com/512/3291/3291695.png" alt="" />
            </a>
          </div>
        </div>
      </section>

      <footer>
        <div className="container">
          <p>Esse é o meu portifolio criado o projeto TDIG</p>
        </div>
      </footer>
    </div>
  )
}

export default App
