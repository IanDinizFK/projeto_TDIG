import { useState } from "react";

export function UpBar() {
    return (
        <nav className="nav">
        <div className="nav-container">
          <a className="home" href="welcome-section">
            <p className="text-white text-center">Home</p>
          </a>
          <a className="projetos" href="#projects">
            <p className="text-white text-center">Projetos</p>
          </a>
          <a className="contato" href="#contact">
            <p className="text-white text-center">Contato</p>
          </a>
        </div>
      </nav>
    )
  }